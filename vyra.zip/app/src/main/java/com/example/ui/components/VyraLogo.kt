package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.PureWhite

@Composable
fun VyraLogo(
    modifier: Modifier = Modifier,
    size: Dp = 120.dp,
    showBorder: Boolean = false,
    elevation: Dp = 0.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .then(if (elevation > 0.dp) Modifier.shadow(elevation, RoundedCornerShape(12.dp)) else Modifier)
            .clip(RoundedCornerShape(12.dp))
            .background(PureWhite)
            .then(
                if (showBorder) Modifier.border(1.dp, LightNeutralBorder, RoundedCornerShape(12.dp))
                else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.vyra_logo_uploaded_1789301358624),
            contentDescription = "Vyra Enterprises Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.matchParentSize()
        )
    }
}

@Composable
fun VyraNavbarLogo(
    modifier: Modifier = Modifier,
    size: Dp = 38.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(8.dp))
            .background(PureWhite)
            .border(1.dp, LightNeutralBorder.copy(alpha = 0.6f), RoundedCornerShape(8.dp)),
        contentAlignment = Alignment.Center
    ) {
        Image(
            painter = painterResource(id = R.drawable.vyra_logo_uploaded_1789301358624),
            contentDescription = "Vyra Logo",
            contentScale = ContentScale.Fit,
            modifier = Modifier.matchParentSize()
        )
    }
}
