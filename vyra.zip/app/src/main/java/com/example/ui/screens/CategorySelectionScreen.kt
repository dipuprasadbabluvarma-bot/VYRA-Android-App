package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.UserSession
import com.example.ui.components.AureliaFooter
import com.example.ui.components.AureliaNavbar
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun CategorySelectionScreen(
    gender: String, // "MEN" or "WOMEN"
    userSession: UserSession,
    businessEmail: String,
    onNavigate: (Screen) -> Unit,
    onNavigateBack: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    val categories = listOf(
        Pair("TOP", "Tailored coats, overshirts, knitwear & blouses"),
        Pair("BOTTOM", "Pleated trousers, flannels, skirts & denim"),
        Pair("FOOTWEAR", "Handcrafted boots, loafers & artisanal footwear"),
        Pair("ACCESSORIES", "Leather goods, silk scarves, jewelry & timepieces")
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Breadcrumbs / Back Navigation Bar
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.size(36.dp).testTag("category_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = CharcoalText,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOME",
                            fontSize = 11.sp,
                            color = MutedText,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable { onNavigate(Screen.Home) }
                        )
                        Text(
                            text = "  /  ",
                            fontSize = 11.sp,
                            color = MutedText
                        )
                        Text(
                            text = gender.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Page Header
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 28.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "CURATED DEPARTMENT",
                        color = ChampagneGold,
                        fontSize = 10.sp,
                        letterSpacing = 2.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = gender.uppercase(),
                        color = CharcoalText,
                        fontSize = 30.sp,
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 4.sp,
                        fontWeight = FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Select an atelier category to inspect tailored affiliate selections.",
                        color = SubtitleGray,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }
            }

            // Exactly the four category options: TOP, BOTTOM, FOOTWEAR, ACCESSORIES
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    categories.forEach { (catName, description) ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectCategory(catName) }
                                .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                                .testTag("select_category_${catName.lowercase()}"),
                            shape = RoundedCornerShape(4.dp),
                            colors = CardDefaults.cardColors(containerColor = PureWhite),
                            elevation = CardDefaults.cardElevation(defaultElevation = 0.5.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 20.dp, vertical = 22.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = catName,
                                        color = CharcoalText,
                                        fontSize = 18.sp,
                                        fontFamily = FontFamily.Serif,
                                        letterSpacing = 2.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = description,
                                        color = SubtitleGray,
                                        fontSize = 12.sp,
                                        lineHeight = 16.sp
                                    )
                                }

                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .border(1.dp, LightNeutralBorder, RoundedCornerShape(18.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowForward,
                                        contentDescription = null,
                                        tint = CharcoalText,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }

            // Footer
            item {
                AureliaFooter(
                    businessEmail = businessEmail,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }
        }
    }
}
