package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LuxuryFashionColorScheme = lightColorScheme(
    primary = CharcoalText,
    onPrimary = PureWhite,
    primaryContainer = SoftBeige,
    onPrimaryContainer = CharcoalText,
    secondary = ChampagneGold,
    onSecondary = PureWhite,
    secondaryContainer = IvoryBackground,
    onSecondaryContainer = DeepCharcoal,
    tertiary = DarkGold,
    onTertiary = PureWhite,
    background = IvoryBackground,
    onBackground = CharcoalText,
    surface = PureWhite,
    onSurface = CharcoalText,
    surfaceVariant = OffWhite,
    onSurfaceVariant = SubtitleGray,
    outline = SoftBorder,
    outlineVariant = LightNeutralBorder
)

@Composable
fun VyraFashionTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = LuxuryFashionColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun AureliaFashionTheme(
    content: @Composable () -> Unit
) = VyraFashionTheme(content = content)
