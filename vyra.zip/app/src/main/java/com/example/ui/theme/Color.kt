package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Fashion Editorial Palette
val PureWhite = Color(0xFFFFFFFF)
val OffWhite = Color(0xFFFDFCF9)
val IvoryBackground = Color(0xFFF7F5F0)
val SoftBeige = Color(0xFFEFEBE4)
val LightNeutralBorder = Color(0xFFE4DFD6)
val SoftBorder = Color(0xFFECE7DF)

// Typography & Accents
val CharcoalText = Color(0xFF141414)
val DeepCharcoal = Color(0xFF262626)
val SubtitleGray = Color(0xFF6E6D68)
val MutedText = Color(0xFF8C8A84)
val ChampagneGold = Color(0xFFB89B6C)
val ChampagneGoldLight = Color(0xFFD8C39F)
val DarkGold = Color(0xFF8F7348)

// Status & Indicators
val SuccessGreen = Color(0xFF2E6930)
val ErrorRed = Color(0xFF8F2929)
