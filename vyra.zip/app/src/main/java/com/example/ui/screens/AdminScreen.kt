package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.SubcomposeAsyncImage
import com.example.auth.UserSession
import com.example.data.model.ArticleEntity
import com.example.data.model.ProductEntity
import com.example.ui.components.AureliaNavbar
import com.example.ui.navigation.AdminSection
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBeige
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray
import com.example.ui.theme.SuccessGreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen(
    userSession: UserSession,
    allProducts: List<ProductEntity>,
    allArticles: List<ArticleEntity>,
    settings: Map<String, String>,
    onSaveProduct: (ProductEntity, () -> Unit) -> Unit,
    onDeleteProduct: (ProductEntity) -> Unit,
    onToggleProductPublish: (ProductEntity) -> Unit,
    onToggleProductFeatured: (ProductEntity) -> Unit,
    onSaveArticle: (ArticleEntity, () -> Unit) -> Unit,
    onDeleteArticle: (ArticleEntity) -> Unit,
    onToggleArticlePublish: (ArticleEntity) -> Unit,
    onUpdateSetting: (String, String) -> Unit,
    onTestUrl: (String) -> Unit,
    onNavigate: (Screen) -> Unit,
    onNavigateBack: () -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    // Normal users must NOT be able to access the admin panel
    if (!userSession.isAdmin) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(IvoryBackground),
            contentAlignment = Alignment.Center
        ) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp)
                    .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                colors = CardDefaults.cardColors(containerColor = PureWhite)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = "Restricted",
                        tint = ErrorRed,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "ACCESS RESTRICTED",
                        fontFamily = FontFamily.Serif,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = CharcoalText,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "You do not possess administrative clearance to inspect this sector.",
                        fontSize = 12.sp,
                        color = SubtitleGray,
                        modifier = Modifier.padding(horizontal = 8.dp)
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                    Button(
                        onClick = onNavigateBack,
                        shape = RoundedCornerShape(2.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalText)
                    ) {
                        Text("RETURN TO SAFETY", fontSize = 11.sp, letterSpacing = 1.sp)
                    }
                }
            }
        }
        return
    }

    var currentSection by remember { mutableStateOf(AdminSection.DASHBOARD) }

    // Product editor dialog state
    var editingProduct by remember { mutableStateOf<ProductEntity?>(null) }
    var isNewProduct by remember { mutableStateOf(false) }

    // Article editor dialog state
    var editingArticle by remember { mutableStateOf<ArticleEntity?>(null) }
    var isNewArticle by remember { mutableStateOf(false) }

    // Settings local edit states
    var instagramUrl by remember(settings) {
        mutableStateOf(settings["instagram_url"] ?: "https://instagram.com/aureliamaison")
    }
    var businessEmail by remember(settings) {
        mutableStateOf(settings["business_email"] ?: "yvraenterprises.business@gmail.com")
    }
    var heroHeading by remember(settings) {
        mutableStateOf(settings["hero_heading"] ?: "THE TIMELESS EDIT")
    }
    var heroStatement by remember(settings) {
        mutableStateOf(settings["hero_statement"] ?: "Sartorial precision, refined silhouettes, and bespoke affiliate curation.")
    }
    var settingsSavedMsg by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(modifier = Modifier.fillMaxSize()) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Admin Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 16.dp, vertical = 12.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onNavigateBack,
                                modifier = Modifier.size(36.dp).testTag("admin_back_button")
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = "Back",
                                    tint = CharcoalText,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "ADMIN CONSOLE",
                                fontSize = 14.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.SemiBold,
                                color = CharcoalText,
                                letterSpacing = 1.sp
                            )
                        }

                        Box(
                            modifier = Modifier
                                .background(CharcoalText, RoundedCornerShape(2.dp))
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "LOCKED / ATELIER OWNER",
                                color = ChampagneGold,
                                fontSize = 9.sp,
                                letterSpacing = 1.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Section Tabs: Dashboard, Products, Categories, Content, Settings
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(PureWhite)
                        .border(width = 0.5.dp, color = SoftBorder)
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AdminSection.values().forEach { section ->
                        val isSelected = currentSection == section
                        Box(
                            modifier = Modifier
                                .background(
                                    if (isSelected) CharcoalText else OffWhite,
                                    RoundedCornerShape(2.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) CharcoalText else SoftBorder,
                                    RoundedCornerShape(2.dp)
                                )
                                .clickable { currentSection = section }
                                .padding(horizontal = 14.dp, vertical = 8.dp)
                                .testTag("admin_tab_${section.name.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = section.label.uppercase(),
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                letterSpacing = 1.sp,
                                color = if (isSelected) PureWhite else DeepCharcoal
                            )
                        }
                    }
                }
            }

            // Tab Contents
            when (currentSection) {
                AdminSection.DASHBOARD -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "ATELIER OVERVIEW",
                                color = CharcoalText,
                                fontSize = 18.sp,
                                fontFamily = FontFamily.Serif,
                                letterSpacing = 1.sp
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                DashboardStatCard(
                                    label = "TOTAL PRODUCTS",
                                    value = allProducts.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                DashboardStatCard(
                                    label = "PUBLISHED",
                                    value = allProducts.count { it.isPublished }.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(12.dp)
                            ) {
                                DashboardStatCard(
                                    label = "FEATURED PIECES",
                                    value = allProducts.count { it.isFeatured }.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                                DashboardStatCard(
                                    label = "ARTICLES",
                                    value = allArticles.size.toString(),
                                    modifier = Modifier.weight(1f)
                                )
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite)
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    Text(
                                        text = "AFFILIATE CONVERSION SYSTEM",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        letterSpacing = 1.sp,
                                        color = ChampagneGold
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "Every product routes customers through its designated external affiliate URL when clicking BOOK NOW. There is no internal cart or checkout required.",
                                        fontSize = 12.sp,
                                        lineHeight = 18.sp,
                                        color = SubtitleGray
                                    )
                                }
                            }
                        }
                    }
                }

                AdminSection.PRODUCTS -> {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "PRODUCTS (${allProducts.size})",
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                color = CharcoalText
                            )
                            Button(
                                onClick = {
                                    editingProduct = ProductEntity(
                                        title = "",
                                        description = "",
                                        gender = "Men",
                                        category = "Top",
                                        imageUrl = "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800",
                                        bookNowUrl = "https://example.com/affiliate",
                                        isPublished = true,
                                        isFeatured = false
                                    )
                                    isNewProduct = true
                                },
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CharcoalText),
                                modifier = Modifier.testTag("admin_add_product_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("NEW PRODUCT", fontSize = 11.sp, letterSpacing = 1.sp)
                            }
                        }
                    }

                    items(allProducts) { product ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 6.dp)
                                .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                                .testTag("admin_product_item_${product.id}"),
                            colors = CardDefaults.cardColors(containerColor = PureWhite)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(OffWhite)
                                ) {
                                    SubcomposeAsyncImage(
                                        model = product.imageUrl,
                                        contentDescription = product.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${product.gender} • ${product.category}".uppercase(),
                                        fontSize = 9.sp,
                                        color = ChampagneGold,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp
                                    )
                                    Text(
                                        text = product.title,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Medium,
                                        color = CharcoalText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "URL: ${product.bookNowUrl}",
                                        fontSize = 10.sp,
                                        color = SubtitleGray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // Toggle Featured
                                    IconButton(
                                        onClick = { onToggleProductFeatured(product) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = if (product.isFeatured) Icons.Default.Star else Icons.Outlined.StarBorder,
                                            contentDescription = "Featured",
                                            tint = if (product.isFeatured) ChampagneGold else SubtitleGray,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    // Toggle Publish
                                    Switch(
                                        checked = product.isPublished,
                                        onCheckedChange = { onToggleProductPublish(product) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = PureWhite,
                                            checkedTrackColor = CharcoalText,
                                            uncheckedThumbColor = SubtitleGray,
                                            uncheckedTrackColor = LightNeutralBorder
                                        ),
                                        modifier = Modifier.size(36.dp)
                                    )

                                    // Edit
                                    IconButton(
                                        onClick = {
                                            editingProduct = product
                                            isNewProduct = false
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CharcoalText, modifier = Modifier.size(16.dp))
                                    }

                                    // Delete
                                    IconButton(
                                        onClick = { onDeleteProduct(product) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSection.CATEGORIES -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "CATEGORY BLUEPRINTS",
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                color = CharcoalText
                            )

                            // Men categories
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "MEN'S ATELIER",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = CharcoalText
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    listOf("Top", "Bottom", "Footwear", "Accessories").forEach { cat ->
                                        val count = allProducts.count { it.gender.equals("Men", ignoreCase = true) && it.category.equals(cat, ignoreCase = true) }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = cat.uppercase(), fontSize = 12.sp, color = DeepCharcoal)
                                            Text(text = "$count items", fontSize = 11.sp, color = SubtitleGray)
                                        }
                                    }
                                }
                            }

                            // Women categories
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite)
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "WOMEN'S ATELIER",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        letterSpacing = 1.sp,
                                        color = CharcoalText
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    listOf("Top", "Bottom", "Footwear", "Accessories").forEach { cat ->
                                        val count = allProducts.count { it.gender.equals("Women", ignoreCase = true) && it.category.equals(cat, ignoreCase = true) }
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(vertical = 4.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(text = cat.uppercase(), fontSize = 12.sp, color = DeepCharcoal)
                                            Text(text = "$count items", fontSize = 11.sp, color = SubtitleGray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSection.CONTENT -> {
                    item {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "JOURNAL ENTRIES (${allArticles.size})",
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                color = CharcoalText
                            )
                            Button(
                                onClick = {
                                    editingArticle = ArticleEntity(
                                        title = "",
                                        description = "",
                                        content = "",
                                        coverImageUrl = "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800",
                                        isPublished = true
                                    )
                                    isNewArticle = true
                                },
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = CharcoalText),
                                modifier = Modifier.testTag("admin_add_article_button")
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("NEW ENTRY", fontSize = 11.sp, letterSpacing = 1.sp)
                            }
                        }
                    }

                    items(allArticles) { article ->
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 20.dp, vertical = 6.dp)
                                .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                            colors = CardDefaults.cardColors(containerColor = PureWhite)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(60.dp)
                                        .clip(RoundedCornerShape(2.dp))
                                        .background(OffWhite)
                                ) {
                                    SubcomposeAsyncImage(
                                        model = article.coverImageUrl,
                                        contentDescription = article.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = article.title,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Serif,
                                        fontWeight = FontWeight.Medium,
                                        color = CharcoalText,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = article.description,
                                        fontSize = 11.sp,
                                        color = SubtitleGray,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Switch(
                                        checked = article.isPublished,
                                        onCheckedChange = { onToggleArticlePublish(article) },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = PureWhite,
                                            checkedTrackColor = CharcoalText
                                        ),
                                        modifier = Modifier.size(36.dp)
                                    )
                                    IconButton(
                                        onClick = {
                                            editingArticle = article
                                            isNewArticle = false
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = CharcoalText, modifier = Modifier.size(16.dp))
                                    }
                                    IconButton(
                                        onClick = { onDeleteArticle(article) },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ErrorRed, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }

                AdminSection.SETTINGS -> {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(20.dp),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Text(
                                text = "ATELIER SETTINGS",
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Serif,
                                color = CharcoalText
                            )

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                                colors = CardDefaults.cardColors(containerColor = PureWhite)
                            ) {
                                Column(modifier = Modifier.padding(18.dp)) {
                                    OutlinedTextField(
                                        value = instagramUrl,
                                        onValueChange = {
                                            instagramUrl = it
                                            settingsSavedMsg = false
                                        },
                                        label = { Text("Instagram Profile URL", fontSize = 12.sp) },
                                        modifier = Modifier.fillMaxWidth().testTag("admin_instagram_input"),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CharcoalText,
                                            unfocusedBorderColor = LightNeutralBorder
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    OutlinedTextField(
                                        value = businessEmail,
                                        onValueChange = {
                                            businessEmail = it
                                            settingsSavedMsg = false
                                        },
                                        label = { Text("Business / Concierge Email", fontSize = 12.sp) },
                                        modifier = Modifier.fillMaxWidth().testTag("admin_email_input"),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CharcoalText,
                                            unfocusedBorderColor = LightNeutralBorder
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    OutlinedTextField(
                                        value = heroHeading,
                                        onValueChange = {
                                            heroHeading = it
                                            settingsSavedMsg = false
                                        },
                                        label = { Text("Hero Section Heading", fontSize = 12.sp) },
                                        modifier = Modifier.fillMaxWidth().testTag("admin_hero_heading_input"),
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CharcoalText,
                                            unfocusedBorderColor = LightNeutralBorder
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(14.dp))

                                    OutlinedTextField(
                                        value = heroStatement,
                                        onValueChange = {
                                            heroStatement = it
                                            settingsSavedMsg = false
                                        },
                                        label = { Text("Hero Section Statement", fontSize = 12.sp) },
                                        modifier = Modifier.fillMaxWidth().testTag("admin_hero_statement_input"),
                                        maxLines = 3,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = CharcoalText,
                                            unfocusedBorderColor = LightNeutralBorder
                                        )
                                    )

                                    if (settingsSavedMsg) {
                                        Spacer(modifier = Modifier.height(10.dp))
                                        Text(
                                            text = "Settings successfully updated in Room database.",
                                            color = SuccessGreen,
                                            fontSize = 12.sp
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(18.dp))

                                    Button(
                                        onClick = {
                                            onUpdateSetting("instagram_url", instagramUrl)
                                            onUpdateSetting("business_email", businessEmail)
                                            onUpdateSetting("hero_heading", heroHeading)
                                            onUpdateSetting("hero_statement", heroStatement)
                                            settingsSavedMsg = true
                                        },
                                        shape = RoundedCornerShape(2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = CharcoalText),
                                        modifier = Modifier.fillMaxWidth().height(44.dp).testTag("save_settings_button")
                                    ) {
                                        Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("SAVE CONFIGURATION", fontSize = 11.sp, letterSpacing = 1.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(50.dp))
            }
        }

        // Product Add/Edit Dialog
        editingProduct?.let { product ->
            Dialog(onDismissRequest = { editingProduct = null }) {
                var pTitle by remember { mutableStateOf(product.title) }
                var pBrand by remember { mutableStateOf(product.brandName) }
                var pDesc by remember { mutableStateOf(product.description) }
                var pGender by remember { mutableStateOf(product.gender) }
                var pCategory by remember { mutableStateOf(product.category) }
                var pImage by remember { mutableStateOf(product.imageUrl) }
                var pBookUrl by remember { mutableStateOf(product.bookNowUrl) }
                var pPublished by remember { mutableStateOf(product.isPublished) }
                var pFeatured by remember { mutableStateOf(product.isFeatured) }
                var pError by remember { mutableStateOf<String?>(null) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                    shape = RoundedCornerShape(4.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite)
                ) {
                    LazyColumn(modifier = Modifier.padding(20.dp)) {
                        item {
                            Text(
                                text = if (isNewProduct) "NEW PRODUCT ENTRY" else "EDIT PRODUCT",
                                fontFamily = FontFamily.Serif,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CharcoalText
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = pTitle,
                                onValueChange = { pTitle = it },
                                label = { Text("Product Name", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("product_edit_name"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pBrand,
                                onValueChange = { pBrand = it },
                                label = { Text("Brand Name (Optional)", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("product_edit_brand"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            // Gender selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Men", "Women").forEach { g ->
                                    val sel = pGender.equals(g, ignoreCase = true)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(if (sel) CharcoalText else OffWhite, RoundedCornerShape(2.dp))
                                            .border(1.dp, if (sel) CharcoalText else SoftBorder, RoundedCornerShape(2.dp))
                                            .clickable { pGender = g }
                                            .padding(vertical = 8.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = g.uppercase(),
                                            fontSize = 11.sp,
                                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (sel) PureWhite else DeepCharcoal
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            // Category selector
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                listOf("Top", "Bottom", "Footwear", "Accessories").forEach { c ->
                                    val sel = pCategory.equals(c, ignoreCase = true)
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(if (sel) CharcoalText else OffWhite, RoundedCornerShape(2.dp))
                                            .border(1.dp, if (sel) CharcoalText else SoftBorder, RoundedCornerShape(2.dp))
                                            .clickable { pCategory = c }
                                            .padding(vertical = 6.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(
                                            text = c,
                                            fontSize = 10.sp,
                                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                                            color = if (sel) PureWhite else DeepCharcoal
                                        )
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pImage,
                                onValueChange = { pImage = it },
                                label = { Text("Product Image URL", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("product_edit_image"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pBookUrl,
                                onValueChange = { pBookUrl = it },
                                label = { Text("BOOK NOW URL (Mandatory Affiliate Link)", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("product_edit_book_url"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = pDesc,
                                onValueChange = { pDesc = it },
                                label = { Text("Short Description", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("product_edit_description"),
                                maxLines = 3
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Published Status", fontSize = 12.sp)
                                Switch(
                                    checked = pPublished,
                                    onCheckedChange = { pPublished = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = PureWhite,
                                        checkedTrackColor = CharcoalText
                                    )
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Featured Piece", fontSize = 12.sp)
                                Switch(
                                    checked = pFeatured,
                                    onCheckedChange = { pFeatured = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = PureWhite,
                                        checkedTrackColor = ChampagneGold
                                    )
                                )
                            }

                            pError?.let {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(it, color = ErrorRed, fontSize = 11.sp)
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { editingProduct = null }) {
                                    Text("CANCEL", color = SubtitleGray, fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        if (pTitle.isBlank()) {
                                            pError = "Please enter product title."
                                            return@Button
                                        }
                                        if (pBookUrl.isBlank()) {
                                            pError = "BOOK NOW URL is required for affiliate conversion."
                                            return@Button
                                        }
                                        val updated = product.copy(
                                            title = pTitle.trim(),
                                            brandName = pBrand.trim(),
                                            description = pDesc.trim(),
                                            gender = pGender,
                                            category = pCategory,
                                            imageUrl = pImage.trim(),
                                            bookNowUrl = pBookUrl.trim(),
                                            isPublished = pPublished,
                                            isFeatured = pFeatured
                                        )
                                        onSaveProduct(updated) {
                                            editingProduct = null
                                        }
                                    },
                                    shape = RoundedCornerShape(2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalText),
                                    modifier = Modifier.testTag("product_save_button")
                                ) {
                                    Text("SAVE PRODUCT", fontSize = 11.sp, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Article Add/Edit Dialog
        editingArticle?.let { article ->
            Dialog(onDismissRequest = { editingArticle = null }) {
                var aTitle by remember { mutableStateOf(article.title) }
                var aDesc by remember { mutableStateOf(article.description) }
                var aContent by remember { mutableStateOf(article.content) }
                var aCover by remember { mutableStateOf(article.coverImageUrl) }
                var aPub by remember { mutableStateOf(article.isPublished) }

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp)
                        .border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
                    shape = RoundedCornerShape(4.dp),
                    colors = CardDefaults.cardColors(containerColor = PureWhite)
                ) {
                    LazyColumn(modifier = Modifier.padding(20.dp)) {
                        item {
                            Text(
                                text = if (isNewArticle) "NEW JOURNAL ESSAY" else "EDIT ARTICLE",
                                fontFamily = FontFamily.Serif,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = CharcoalText
                            )
                            Spacer(modifier = Modifier.height(14.dp))

                            OutlinedTextField(
                                value = aTitle,
                                onValueChange = { aTitle = it },
                                label = { Text("Article Title", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().testTag("article_edit_title"),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = aCover,
                                onValueChange = { aCover = it },
                                label = { Text("Cover Image URL", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = aDesc,
                                onValueChange = { aDesc = it },
                                label = { Text("Short Description / Excerpt", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth(),
                                maxLines = 2
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = aContent,
                                onValueChange = { aContent = it },
                                label = { Text("Article Content", fontSize = 12.sp) },
                                modifier = Modifier.fillMaxWidth().height(120.dp),
                                maxLines = 6
                            )
                            Spacer(modifier = Modifier.height(12.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Published Status", fontSize = 12.sp)
                                Switch(
                                    checked = aPub,
                                    onCheckedChange = { aPub = it },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = PureWhite,
                                        checkedTrackColor = CharcoalText
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(18.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End
                            ) {
                                TextButton(onClick = { editingArticle = null }) {
                                    Text("CANCEL", color = SubtitleGray, fontSize = 11.sp)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val updated = article.copy(
                                            title = aTitle.trim(),
                                            description = aDesc.trim(),
                                            content = aContent.trim(),
                                            coverImageUrl = aCover.trim(),
                                            isPublished = aPub
                                        )
                                        onSaveArticle(updated) {
                                            editingArticle = null
                                        }
                                    },
                                    shape = RoundedCornerShape(2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalText)
                                ) {
                                    Text("SAVE ESSAY", fontSize = 11.sp, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DashboardStatCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier.border(1.dp, SoftBorder, RoundedCornerShape(4.dp)),
        colors = CardDefaults.cardColors(containerColor = PureWhite),
        shape = RoundedCornerShape(4.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = label, fontSize = 10.sp, letterSpacing = 1.sp, color = SubtitleGray, fontWeight = FontWeight.Medium)
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontSize = 24.sp, fontFamily = FontFamily.Serif, color = CharcoalText, fontWeight = FontWeight.SemiBold)
        }
    }
}
