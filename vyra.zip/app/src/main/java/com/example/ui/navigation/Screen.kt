package com.example.ui.navigation

sealed class Screen(val route: String) {
    object Login : Screen("login")
    object Home : Screen("home")
    object MenCategory : Screen("men")
    object WomenCategory : Screen("women")
    data class ProductList(val gender: String, val category: String) : Screen("products/$gender/$category")
    object Content : Screen("content")
    data class ArticleDetail(val articleId: Long) : Screen("content/$articleId")
    object Profile : Screen("profile")
    object Help : Screen("help")
    object PrivacyPolicy : Screen("privacy-policy")
    object TermsConditions : Screen("terms")
    object AffiliateDisclosure : Screen("affiliate-disclosure")
    data class Admin(val section: AdminSection = AdminSection.DASHBOARD) : Screen("admin")
}

enum class AdminSection(val label: String) {
    DASHBOARD("Dashboard"),
    PRODUCTS("Products"),
    CATEGORIES("Categories"),
    CONTENT("Content"),
    SETTINGS("Settings")
}
