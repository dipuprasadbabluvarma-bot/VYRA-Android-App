package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.UserSession
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun AureliaNavbar(
    userSession: UserSession,
    onNavigate: (Screen) -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    var mobileMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(PureWhite)
            .statusBarsPadding()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Brand Logo / Home Link
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { onNavigate(Screen.Home) }
                    .testTag("navbar_logo")
            ) {
                VyraNavbarLogo(size = 34.dp)
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "VYRA",
                        color = CharcoalText,
                        fontSize = 17.sp,
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "ENTERPRISES",
                        color = ChampagneGold,
                        fontSize = 8.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
            }

            // Desktop / Wide Screen Navigation Links & Actions
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (userSession.isAdmin) {
                    IconButton(
                        onClick = { onNavigate(Screen.Admin()) },
                        modifier = Modifier.size(40.dp).testTag("navbar_admin_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.AdminPanelSettings,
                            contentDescription = "Admin Panel",
                            tint = ChampagneGold,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                IconButton(
                    onClick = { onNavigate(Screen.Profile) },
                    modifier = Modifier.size(40.dp).testTag("navbar_profile_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "User Profile",
                        tint = DeepCharcoal,
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Hamburger Menu Button for all secondary and primary links
                IconButton(
                    onClick = { mobileMenuExpanded = !mobileMenuExpanded },
                    modifier = Modifier.size(40.dp).testTag("navbar_menu_toggle")
                ) {
                    Icon(
                        imageVector = if (mobileMenuExpanded) Icons.Default.Close else Icons.Default.Menu,
                        contentDescription = "Navigation Menu",
                        tint = CharcoalText,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }

        // Expanded Navigation Drawer / Dropdown
        AnimatedVisibility(visible = mobileMenuExpanded) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(IvoryBackground)
                    .border(1.dp, SoftBorder)
                    .padding(horizontal = 24.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                NavMenuItem("HOME") {
                    mobileMenuExpanded = false
                    onNavigate(Screen.Home)
                }
                NavMenuItem("MEN'S COLLECTION") {
                    mobileMenuExpanded = false
                    onNavigate(Screen.MenCategory)
                }
                NavMenuItem("WOMEN'S COLLECTION") {
                    mobileMenuExpanded = false
                    onNavigate(Screen.WomenCategory)
                }
                NavMenuItem("EDITORIAL CONTENT") {
                    mobileMenuExpanded = false
                    onNavigate(Screen.Content)
                }
                NavMenuItem("INSTAGRAM") {
                    mobileMenuExpanded = false
                    onOpenInstagram()
                }
                NavMenuItem("HELP & CONCIERGE") {
                    mobileMenuExpanded = false
                    onOpenHelp()
                }
                NavMenuItem("MY PROFILE") {
                    mobileMenuExpanded = false
                    onNavigate(Screen.Profile)
                }
                if (userSession.isAdmin) {
                    NavMenuItem("ADMIN PANEL (LOCKED)") {
                        mobileMenuExpanded = false
                        onNavigate(Screen.Admin())
                    }
                }
            }
        }

        HorizontalDivider(thickness = 1.dp, color = SoftBorder)
    }
}

@Composable
private fun NavMenuItem(title: String, onClick: () -> Unit) {
    Text(
        text = title,
        color = CharcoalText,
        fontSize = 13.sp,
        letterSpacing = 1.5.sp,
        fontWeight = FontWeight.Medium,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp)
    )
}
