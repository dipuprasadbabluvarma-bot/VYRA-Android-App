package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import com.example.auth.UserSession
import com.example.ui.components.AureliaFooter
import com.example.ui.components.AureliaNavbar
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBeige
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun ProfileScreen(
    userSession: UserSession,
    businessEmail: String,
    onLogout: () -> Unit,
    onToggleAdmin: () -> Unit,
    onNavigate: (Screen) -> Unit,
    onNavigateBack: () -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Breadcrumbs / Back Navigation
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.size(36.dp).testTag("profile_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = CharcoalText,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOME",
                            fontSize = 11.sp,
                            color = MutedText,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable { onNavigate(Screen.Home) }
                        )
                        Text(text = "  /  ", fontSize = 11.sp, color = MutedText)
                        Text(
                            text = "MY PROFILE",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Profile Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                            .testTag("profile_main_card"),
                        shape = RoundedCornerShape(4.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Avatar
                            Box(
                                modifier = Modifier
                                    .size(80.dp)
                                    .clip(CircleShape)
                                    .background(SoftBeige),
                                contentAlignment = Alignment.Center
                            ) {
                                if (userSession.avatarUrl != null) {
                                    SubcomposeAsyncImage(
                                        model = userSession.avatarUrl,
                                        contentDescription = userSession.userName,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = null,
                                        tint = CharcoalText,
                                        modifier = Modifier.size(44.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Text(
                                text = userSession.userName.ifBlank { "Valued Client" },
                                color = CharcoalText,
                                fontSize = 20.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = userSession.userEmail.ifBlank { "client@aureliamaison.com" },
                                color = SubtitleGray,
                                fontSize = 13.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Box(
                                modifier = Modifier
                                    .background(SoftBeige, RoundedCornerShape(2.dp))
                                    .padding(horizontal = 10.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "AUTHENTICATION: ${userSession.authProvider.uppercase()}",
                                    color = CharcoalText,
                                    fontSize = 10.sp,
                                    letterSpacing = 1.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Spacer(modifier = Modifier.height(24.dp))
                            HorizontalDivider(thickness = 0.5.dp, color = SoftBorder)
                            Spacer(modifier = Modifier.height(20.dp))

                            // Admin access toggle & entry
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Security,
                                        contentDescription = null,
                                        tint = ChampagneGold,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "Administrator Privileges",
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Medium,
                                            color = CharcoalText
                                        )
                                        Text(
                                            text = if (userSession.isAdmin) "Access to product & editorial suite" else "Standard client account",
                                            fontSize = 11.sp,
                                            color = SubtitleGray
                                        )
                                    }
                                }

                                Switch(
                                    checked = userSession.isAdmin,
                                    onCheckedChange = { onToggleAdmin() },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = PureWhite,
                                        checkedTrackColor = CharcoalText,
                                        uncheckedThumbColor = SubtitleGray,
                                        uncheckedTrackColor = LightNeutralBorder
                                    ),
                                    modifier = Modifier.testTag("admin_privileges_switch")
                                )
                            }

                            if (userSession.isAdmin) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Button(
                                    onClick = { onNavigate(Screen.Admin()) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(44.dp)
                                        .testTag("open_admin_panel_button"),
                                    shape = RoundedCornerShape(2.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = CharcoalText)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.AdminPanelSettings,
                                            contentDescription = null,
                                            tint = ChampagneGold,
                                            modifier = Modifier.size(16.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "OPEN ADMIN CONTROL PANEL",
                                            fontSize = 11.sp,
                                            letterSpacing = 1.5.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(24.dp))

                            // Logout Button
                            OutlinedButton(
                                onClick = onLogout,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .testTag("profile_logout_button"),
                                shape = RoundedCornerShape(2.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = ErrorRed),
                                border = ButtonDefaults.outlinedButtonBorder.copy(width = 1.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Logout,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp),
                                        tint = ErrorRed
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "LOGOUT OF ATELIER",
                                        fontSize = 11.sp,
                                        letterSpacing = 1.5.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }

            // Footer
            item {
                AureliaFooter(
                    businessEmail = businessEmail,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }
        }
    }
}
