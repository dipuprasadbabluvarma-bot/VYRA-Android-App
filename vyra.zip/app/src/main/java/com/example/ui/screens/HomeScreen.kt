package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Diamond
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.auth.UserSession
import com.example.ui.components.AureliaFooter
import com.example.ui.components.AureliaNavbar
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBeige
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun HomeScreen(
    userSession: UserSession,
    greeting: String,
    businessEmail: String,
    heroHeading: String,
    heroStatement: String,
    onNavigate: (Screen) -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Dynamic Greeting Bar
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 24.dp, vertical = 14.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = greeting,
                            color = CharcoalText,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Serif,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.5.sp,
                            modifier = Modifier.testTag("home_greeting_text")
                        )
                        Text(
                            text = "AURELIA ATELIER",
                            color = ChampagneGold,
                            fontSize = 10.sp,
                            letterSpacing = 1.5.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Hero Section
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 18.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                            .testTag("home_hero_card"),
                        shape = RoundedCornerShape(4.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column {
                            // Hero Image
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_hero_fashion),
                                    contentDescription = "Vyra Enterprises Luxury Hero",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }

                            // Hero Typography
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "EDITORIAL COLLECTION",
                                    color = ChampagneGold,
                                    fontSize = 10.sp,
                                    letterSpacing = 2.5.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = heroHeading,
                                    color = CharcoalText,
                                    fontSize = 22.sp,
                                    fontFamily = FontFamily.Serif,
                                    letterSpacing = 2.sp,
                                    textAlign = TextAlign.Center,
                                    fontWeight = FontWeight.Normal
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = heroStatement,
                                    color = SubtitleGray,
                                    fontSize = 13.sp,
                                    lineHeight = 19.sp,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 12.dp)
                                )
                            }
                        }
                    }
                }
            }

            // Navigation Section: MEN & WOMEN Major Options
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "EXPLORE BY GENDER",
                        color = CharcoalText,
                        fontSize = 12.sp,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(bottom = 12.dp, start = 4.dp)
                    )

                    // MEN Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(Screen.MenCategory) }
                            .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                            .testTag("home_men_card"),
                        shape = RoundedCornerShape(4.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_men_category),
                                    contentDescription = "Men's Collection",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(18.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "MEN",
                                    color = CharcoalText,
                                    fontSize = 20.sp,
                                    fontFamily = FontFamily.Serif,
                                    letterSpacing = 2.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Top, Bottom, Footwear & Accessories",
                                    color = SubtitleGray,
                                    fontSize = 12.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .border(1.dp, LightNeutralBorder, RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = CharcoalText,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // WOMEN Card
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigate(Screen.WomenCategory) }
                            .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                            .testTag("home_women_card"),
                        shape = RoundedCornerShape(4.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(3.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.img_women_category),
                                    contentDescription = "Women's Collection",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(18.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "WOMEN",
                                    color = CharcoalText,
                                    fontSize = 20.sp,
                                    fontFamily = FontFamily.Serif,
                                    letterSpacing = 2.sp,
                                    fontWeight = FontWeight.Medium
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Top, Bottom, Footwear & Accessories",
                                    color = SubtitleGray,
                                    fontSize = 12.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .border(1.dp, LightNeutralBorder, RoundedCornerShape(18.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.ArrowForward,
                                    contentDescription = null,
                                    tint = CharcoalText,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }
            }

            // 21. HOME QUICK LINKS: INSTAGRAM | HELP | CONTENT
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 20.dp)
                ) {
                    HorizontalDivider(thickness = 0.5.dp, color = SoftBorder)
                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        QuickLinkItem("INSTAGRAM") { onOpenInstagram() }
                        Text("|", color = MutedText, fontSize = 12.sp)
                        QuickLinkItem("HELP") { onOpenHelp() }
                        Text("|", color = MutedText, fontSize = 12.sp)
                        QuickLinkItem("CONTENT") { onNavigate(Screen.Content) }
                    }

                    Spacer(modifier = Modifier.height(18.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = SoftBorder)
                }
            }

            // Footer
            item {
                AureliaFooter(
                    businessEmail = businessEmail,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }
        }
    }
}

@Composable
private fun QuickLinkItem(text: String, onClick: () -> Unit) {
    Text(
        text = text,
        color = CharcoalText,
        fontSize = 12.sp,
        fontFamily = FontFamily.SansSerif,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 2.sp,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("quick_link_${text.lowercase()}")
    )
}
