package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.UserSession
import com.example.ui.components.AureliaFooter
import com.example.ui.components.AureliaNavbar
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun LegalScreen(
    title: String,
    subtitle: String,
    content: String,
    userSession: UserSession,
    businessEmail: String,
    onNavigate: (Screen) -> Unit,
    onNavigateBack: () -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Breadcrumbs / Back Navigation
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.size(36.dp).testTag("legal_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = CharcoalText,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOME",
                            fontSize = 11.sp,
                            color = MutedText,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable { onNavigate(Screen.Home) }
                        )
                        Text(text = "  /  ", fontSize = 11.sp, color = MutedText)
                        Text(
                            text = title.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Legal Document Card
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, SoftBorder, RoundedCornerShape(4.dp))
                            .testTag("legal_content_card"),
                        shape = RoundedCornerShape(4.dp),
                        colors = CardDefaults.cardColors(containerColor = PureWhite),
                        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(24.dp)
                        ) {
                            Text(
                                text = "LEGAL PROTOCOL",
                                color = ChampagneGold,
                                fontSize = 10.sp,
                                letterSpacing = 2.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = title,
                                color = CharcoalText,
                                fontSize = 22.sp,
                                fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Normal,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = subtitle,
                                color = SubtitleGray,
                                fontSize = 12.sp
                            )
                            Spacer(modifier = Modifier.height(20.dp))

                            Text(
                                text = content,
                                color = DeepCharcoal,
                                fontSize = 13.sp,
                                lineHeight = 22.sp
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }

            // Footer
            item {
                AureliaFooter(
                    businessEmail = businessEmail,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }
        }
    }
}
