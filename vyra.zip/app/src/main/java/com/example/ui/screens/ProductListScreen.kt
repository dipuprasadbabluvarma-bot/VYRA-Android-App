package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.auth.UserSession
import com.example.data.model.ProductEntity
import com.example.ui.components.AureliaFooter
import com.example.ui.components.AureliaNavbar
import com.example.ui.components.EmptyState
import com.example.ui.components.ProductCard
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.LightNeutralBorder
import com.example.ui.theme.MutedText
import com.example.ui.theme.OffWhite
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun ProductListScreen(
    gender: String,
    category: String,
    products: List<ProductEntity>,
    searchQuery: String,
    featuredFilter: Boolean,
    userSession: UserSession,
    businessEmail: String,
    onSearchChange: (String) -> Unit,
    onToggleFeatured: () -> Unit,
    onBookNow: (String) -> Unit,
    onNavigate: (Screen) -> Unit,
    onNavigateBack: () -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(IvoryBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize()
        ) {
            // Navbar
            item {
                AureliaNavbar(
                    userSession = userSession,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }

            // Breadcrumbs / Back Navigation
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(OffWhite)
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                        .border(width = 0.5.dp, color = SoftBorder)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = onNavigateBack,
                            modifier = Modifier.size(36.dp).testTag("product_list_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = CharcoalText,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "HOME",
                            fontSize = 11.sp,
                            color = MutedText,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable { onNavigate(Screen.Home) }
                        )
                        Text(text = "  /  ", fontSize = 11.sp, color = MutedText)
                        Text(
                            text = gender.uppercase(),
                            fontSize = 11.sp,
                            color = MutedText,
                            letterSpacing = 1.sp,
                            modifier = Modifier.clickable {
                                if (gender.equals("Men", ignoreCase = true)) {
                                    onNavigate(Screen.MenCategory)
                                } else {
                                    onNavigate(Screen.WomenCategory)
                                }
                            }
                        )
                        Text(text = "  /  ", fontSize = 11.sp, color = MutedText)
                        Text(
                            text = category.uppercase(),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = CharcoalText,
                            letterSpacing = 1.sp
                        )
                    }
                }
            }

            // Category Title & Count
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$gender • $category".uppercase(),
                        color = ChampagneGold,
                        fontSize = 10.sp,
                        letterSpacing = 2.5.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "${category.uppercase()} COLLECTION",
                        color = CharcoalText,
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Serif,
                        letterSpacing = 2.sp,
                        fontWeight = FontWeight.Normal
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "${products.size} curations available for affiliate booking",
                        color = SubtitleGray,
                        fontSize = 12.sp
                    )
                }
            }

            // Search Bar & Filter Controls
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 6.dp)
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = onSearchChange,
                        placeholder = { Text("Search by title or designer brand...", fontSize = 12.sp, color = MutedText) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("product_search_input"),
                        singleLine = true,
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = "Search", tint = SubtitleGray, modifier = Modifier.size(18.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { onSearchChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = "Clear", tint = SubtitleGray, modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CharcoalText,
                            unfocusedBorderColor = LightNeutralBorder,
                            focusedContainerColor = PureWhite,
                            unfocusedContainerColor = PureWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        FilterChip(
                            selected = featuredFilter,
                            onClick = onToggleFeatured,
                            label = {
                                Text(
                                    text = if (featuredFilter) "FEATURED ONLY (ACTIVE)" else "FEATURED ONLY",
                                    fontSize = 11.sp,
                                    letterSpacing = 1.sp
                                )
                            },
                            modifier = Modifier.testTag("filter_featured_chip"),
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = CharcoalText,
                                selectedLabelColor = PureWhite,
                                containerColor = PureWhite,
                                labelColor = CharcoalText
                            ),
                            border = FilterChipDefaults.filterChipBorder(
                                enabled = true,
                                selected = featuredFilter,
                                borderColor = if (featuredFilter) CharcoalText else LightNeutralBorder
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            // Product Grid Content
            if (products.isEmpty()) {
                item {
                    EmptyState(
                        message = "New styles are coming soon.",
                        subtitle = if (searchQuery.isNotEmpty()) "No pieces matching '$searchQuery'." else "Our curation atelier is currently selecting pieces for $gender $category."
                    )
                }
            } else {
                // Responsive Grid: 2 columns on mobile, 3-4 on tablet/desktop
                item {
                    BoxWithConstraints(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 8.dp)
                    ) {
                        val columns = when {
                            maxWidth >= 1000.dp -> 4
                            maxWidth >= 600.dp -> 3
                            else -> 2
                        }

                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            // Chunk items into rows for smooth nested scrolling
                            val rows = products.chunked(columns)
                            rows.forEach { rowItems ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    rowItems.forEach { product ->
                                        Box(modifier = Modifier.weight(1f)) {
                                            ProductCard(
                                                product = product,
                                                onBookNow = onBookNow
                                            )
                                        }
                                    }
                                    // Empty weight spacers if row is not full
                                    val emptySlots = columns - rowItems.size
                                    for (i in 0 until emptySlots) {
                                        Spacer(modifier = Modifier.weight(1f))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }

            // Footer
            item {
                AureliaFooter(
                    businessEmail = businessEmail,
                    onNavigate = onNavigate,
                    onOpenInstagram = onOpenInstagram,
                    onOpenHelp = onOpenHelp
                )
            }
        }
    }
}
