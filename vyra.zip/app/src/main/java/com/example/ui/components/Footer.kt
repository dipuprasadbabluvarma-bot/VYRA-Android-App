package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.navigation.Screen
import com.example.ui.theme.ChampagneGold
import com.example.ui.theme.CharcoalText
import com.example.ui.theme.DeepCharcoal
import com.example.ui.theme.IvoryBackground
import com.example.ui.theme.MutedText
import com.example.ui.theme.SoftBeige
import com.example.ui.theme.SoftBorder
import com.example.ui.theme.SubtitleGray

@Composable
fun AureliaFooter(
    businessEmail: String,
    onNavigate: (Screen) -> Unit,
    onOpenInstagram: () -> Unit,
    onOpenHelp: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(IvoryBackground)
            .padding(top = 40.dp, bottom = 24.dp)
            .navigationBarsPadding()
    ) {
        HorizontalDivider(thickness = 1.dp, color = SoftBorder)
        Spacer(modifier = Modifier.height(32.dp))

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Brand Logo / Emblem
            VyraLogo(
                size = 72.dp,
                showBorder = true
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "VYRA ENTERPRISES",
                color = CharcoalText,
                fontSize = 15.sp,
                fontFamily = FontFamily.Serif,
                letterSpacing = 2.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "A curated luxury fashion discovery and editorial affiliate platform celebrating sartorial refinement and intentional design.",
                color = SubtitleGray,
                fontSize = 12.sp,
                lineHeight = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Navigation Links
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FooterLink("MEN") { onNavigate(Screen.MenCategory) }
                FooterDivider()
                FooterLink("WOMEN") { onNavigate(Screen.WomenCategory) }
                FooterDivider()
                FooterLink("CONTENT") { onNavigate(Screen.Content) }
                FooterDivider()
                FooterLink("INSTAGRAM") { onOpenInstagram() }
                FooterDivider()
                FooterLink("HELP") { onOpenHelp() }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Contact Email
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.clickable { onOpenHelp() }
            ) {
                Text(
                    text = "Concierge: ",
                    color = SubtitleGray,
                    fontSize = 12.sp
                )
                Text(
                    text = businessEmail,
                    color = CharcoalText,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(thickness = 0.5.dp, color = SoftBorder)
            Spacer(modifier = Modifier.height(16.dp))

            // Legal Links
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                FooterLink("PRIVACY POLICY") { onNavigate(Screen.PrivacyPolicy) }
                FooterDivider()
                FooterLink("TERMS & CONDITIONS") { onNavigate(Screen.TermsConditions) }
                FooterDivider()
                FooterLink("AFFILIATE DISCLOSURE") { onNavigate(Screen.AffiliateDisclosure) }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "© 2026 VYRA ENTERPRISES. ALL RIGHTS RESERVED.",
                color = MutedText,
                fontSize = 10.sp,
                letterSpacing = 1.2.sp
            )
        }
    }
}

@Composable
private fun FooterLink(title: String, onClick: () -> Unit) {
    Text(
        text = title,
        color = DeepCharcoal,
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
        letterSpacing = 1.sp,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 4.dp)
    )
}

@Composable
private fun FooterDivider() {
    Text(
        text = "•",
        color = MutedText,
        fontSize = 10.sp,
        modifier = Modifier.padding(horizontal = 2.dp)
    )
}
