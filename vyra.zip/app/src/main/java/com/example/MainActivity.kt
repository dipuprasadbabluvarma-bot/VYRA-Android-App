package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.ui.FashionViewModel
import com.example.ui.components.HelpDialog
import com.example.ui.navigation.Screen
import com.example.ui.screens.AdminScreen
import com.example.ui.screens.CategorySelectionScreen
import com.example.ui.screens.ContentScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LegalScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.ProductListScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.theme.VyraFashionTheme

class MainActivity : ComponentActivity() {

    private val viewModel: FashionViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VyraFashionTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VyraApp(viewModel = viewModel)
                }
            }
        }
    }
}

@Composable
fun AureliaMaisonApp(viewModel: FashionViewModel) = VyraApp(viewModel)

@Composable
fun VyraApp(viewModel: FashionViewModel) {
    val context = LocalContext.current
    val currentScreen by viewModel.currentScreen.collectAsState()
    val userSession by viewModel.userSession.collectAsState()
    val authUiState by viewModel.authUiState.collectAsState()
    val allProducts by viewModel.allProducts.collectAsState()
    val publishedProducts by viewModel.publishedProducts.collectAsState()
    val allArticles by viewModel.allArticles.collectAsState()
    val publishedArticles by viewModel.publishedArticles.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val featuredFilter by viewModel.featuredFilter.collectAsState()

    val businessEmail = viewModel.getBusinessEmail()
    val heroHeading = settings["hero_heading"] ?: "THE TIMELESS EDIT"
    val heroStatement = settings["hero_statement"] ?: "Sartorial precision, refined silhouettes, and bespoke affiliate curation."

    // Intercept system Back button
    BackHandler(enabled = currentScreen !is Screen.Login && currentScreen !is Screen.Home) {
        viewModel.navigateBack()
    }

    when (val screen = currentScreen) {
        is Screen.Login -> {
            LoginScreen(
                authUiState = authUiState,
                businessEmail = businessEmail,
                onLoginWithGoogle = { viewModel.loginWithGoogle() },
                onSignInWithEmail = { e, p -> viewModel.signInWithEmail(e, p) },
                onSignUpWithEmail = { n, e, p -> viewModel.signUpWithEmail(n, e, p) },
                onForgotPassword = { e -> viewModel.forgotPassword(e) },
                onSendEmailDirectly = { viewModel.sendEmail(context) }
            )
        }

        is Screen.Home -> {
            HomeScreen(
                userSession = userSession,
                greeting = viewModel.getGreeting(),
                businessEmail = businessEmail,
                heroHeading = heroHeading,
                heroStatement = heroStatement,
                onNavigate = { viewModel.navigateTo(it) },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.MenCategory -> {
            CategorySelectionScreen(
                gender = "Men",
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onSelectCategory = { cat ->
                    viewModel.setSearchQuery("")
                    viewModel.navigateTo(Screen.ProductList("Men", cat))
                },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.WomenCategory -> {
            CategorySelectionScreen(
                gender = "Women",
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onSelectCategory = { cat ->
                    viewModel.setSearchQuery("")
                    viewModel.navigateTo(Screen.ProductList("Women", cat))
                },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.ProductList -> {
            val filteredProducts = viewModel.getFilteredProducts(screen.gender, screen.category)
            ProductListScreen(
                gender = screen.gender,
                category = screen.category,
                products = filteredProducts,
                searchQuery = searchQuery,
                featuredFilter = featuredFilter,
                userSession = userSession,
                businessEmail = businessEmail,
                onSearchChange = { viewModel.setSearchQuery(it) },
                onToggleFeatured = { viewModel.toggleFeaturedFilter() },
                onBookNow = { url -> viewModel.openBookNowUrl(context, url) },
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.Content -> {
            ContentScreen(
                articles = publishedArticles,
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.ArticleDetail -> {
            ContentScreen(
                articles = publishedArticles,
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.Profile -> {
            ProfileScreen(
                userSession = userSession,
                businessEmail = businessEmail,
                onLogout = { viewModel.logout() },
                onToggleAdmin = { viewModel.toggleAdminStatus() },
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.Help -> {
            HelpDialog(
                businessEmail = businessEmail,
                onDismiss = { viewModel.navigateBack() },
                onSendEmailDirectly = { viewModel.sendEmail(context) }
            )
        }

        is Screen.Admin -> {
            AdminScreen(
                userSession = userSession,
                allProducts = allProducts,
                allArticles = allArticles,
                settings = settings,
                onSaveProduct = { p, done -> viewModel.saveProduct(p, done) },
                onDeleteProduct = { p -> viewModel.deleteProduct(p) },
                onToggleProductPublish = { p -> viewModel.toggleProductPublish(p) },
                onToggleProductFeatured = { p -> viewModel.toggleProductFeatured(p) },
                onSaveArticle = { a, done -> viewModel.saveArticle(a, done) },
                onDeleteArticle = { a -> viewModel.deleteArticle(a) },
                onToggleArticlePublish = { a -> viewModel.toggleArticlePublish(a) },
                onUpdateSetting = { k, v -> viewModel.updateSetting(k, v) },
                onTestUrl = { url -> viewModel.openBookNowUrl(context, url) },
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.PrivacyPolicy -> {
            LegalScreen(
                title = "Privacy Policy",
                subtitle = "Last Updated: 2026 • Vyra Enterprises Atelier",
                content = """
                    1. INTRODUCTION
                    Vyra Enterprises ("we", "our", or "Vyra") respects your privacy and is committed to protecting the personal data of our discerning clientele. This Privacy Policy details how we handle information gathered across our affiliate discovery platform.

                    2. INFORMATION WE COLLECT
                    We collect minimal personal data essential to providing a seamless experience:
                    - Account Identification: Name, email address, and optional avatar URL obtained during registration or via Google Sign-In.
                    - Browsing Preferences: Local category filters and saved preferences.
                    - Technical Telemetry: Standard device parameters for layout optimization.

                    3. AFFILIATE LINKS & EXTERNAL DESTINATIONS
                    Vyra Enterprises operates exclusively as a curated product discovery and affiliate portal. Clicking "BOOK NOW" redirects your session to third-party partner portals. We do not store, process, or transmit financial credentials or payment cards.

                    4. DATA PROTECTION & RETENTION
                    All user preferences and account states are securely handled using industry-standard security protocols. We do not sell, rent, or lease personal information to outside marketing entities.

                    5. CONTACT CONCIERGE
                    For questions regarding data processing or privacy inquiries, contact our client team at $businessEmail.
                """.trimIndent(),
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.TermsConditions -> {
            LegalScreen(
                title = "Terms & Conditions",
                subtitle = "Atelier Governance • Vyra Enterprises",
                content = """
                    1. ACCEPTANCE OF TERMS
                    By accessing or creating an account within Vyra Enterprises (Vyra), you agree to comply with and be bound by these Terms and Conditions.

                    2. NATURE OF SERVICE
                    Vyra Enterprises is an independent luxury fashion curation and affiliate showcase platform. We are NOT a direct vendor, merchant of record, or payment processor. We do not maintain shopping carts, process monetary transactions, or issue order shipments directly.

                    3. BOOK NOW CONVERSION & EXTERNAL SITES
                    The "BOOK NOW" action transfers your session to our third-party luxury retail affiliates and brand partners. Any purchase, order fulfillment, return, or warranty claim is governed strictly by the respective merchant's terms of service.

                    4. INTELLECTUAL PROPERTY
                    All proprietary branding, editorial compositions, layouts, and curated journal entries are protected under applicable intellectual property laws.

                    5. REVISION OF TERMS
                    We reserve the right to revise these Terms at any time. Continued use of the atelier constitutes acceptance of any modifications.
                """.trimIndent(),
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }

        is Screen.AffiliateDisclosure -> {
            LegalScreen(
                title = "Affiliate Disclosure",
                subtitle = "Transparency & Partner Relations",
                content = """
                    1. AFFILIATE RELATIONSHIP DISCLOSURE
                    In full compliance with international advertising standards and fair business practices, Vyra Enterprises discloses that certain links featured on this platform are affiliate links.

                    2. HOW IT WORKS
                    When you click on the "BOOK NOW" button for a featured garment, footwear, or accessory, you are redirected to the authorized merchant or brand partner's external portal. If you complete a transaction, Vyra Enterprises may receive a modest referral commission from the merchant at ABSOLUTELY NO ADDITIONAL COST to you.

                    3. EDITORIAL INTEGRITY
                    Our editorial curation is guided solely by sartorial merit, silhouette quality, craftsmanship, and aesthetic cohesion. We do not accept payment to promote inferior or unverified garments.

                    4. PRICING & AVAILABILITY
                    Because we do not control third-party inventory or pricing schedules, availability and prices are subject to the respective merchant's live platform at the moment of booking.
                """.trimIndent(),
                userSession = userSession,
                businessEmail = businessEmail,
                onNavigate = { viewModel.navigateTo(it) },
                onNavigateBack = { viewModel.navigateBack() },
                onOpenInstagram = { viewModel.openInstagram(context) },
                onOpenHelp = { viewModel.navigateTo(Screen.Help) }
            )
        }
    }
}
