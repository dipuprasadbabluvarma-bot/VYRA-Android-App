package com.example.auth

data class UserSession(
    val isLoggedIn: Boolean = false,
    val userName: String = "",
    val userEmail: String = "",
    val avatarUrl: String? = null,
    val authProvider: String = "None",
    val isAdmin: Boolean = false
)

sealed interface AuthUiState {
    object Idle : AuthUiState
    object Loading : AuthUiState
    data class Success(val message: String) : AuthUiState
    data class Error(val message: String) : AuthUiState
}
