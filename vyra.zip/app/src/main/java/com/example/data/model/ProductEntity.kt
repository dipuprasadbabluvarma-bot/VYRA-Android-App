package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val description: String,
    val brandName: String = "",
    val gender: String, // "Men" or "Women"
    val category: String, // "Top", "Bottom", "Footwear", "Accessories"
    val imageUrl: String,
    val bookNowUrl: String,
    val isPublished: Boolean = true,
    val isFeatured: Boolean = false,
    val displayOrder: Int = 0,
    val createdAt: Long = System.currentTimeMillis()
)
