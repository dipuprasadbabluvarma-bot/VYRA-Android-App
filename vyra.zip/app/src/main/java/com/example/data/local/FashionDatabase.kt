package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.ArticleEntity
import com.example.data.model.ProductEntity
import com.example.data.model.SettingEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [ProductEntity::class, ArticleEntity::class, SettingEntity::class],
    version = 1,
    exportSchema = false
)
abstract class FashionDatabase : RoomDatabase() {
    abstract fun fashionDao(): FashionDao

    companion object {
        @Volatile
        private var INSTANCE: FashionDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): FashionDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    FashionDatabase::class.java,
                    "aurelia_fashion_db"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.fashionDao())
                    }
                }
            }
        }

        suspend fun populateInitialData(dao: FashionDao) {
            // Seed Settings
            val initialSettings = listOf(
                SettingEntity("instagram_url", "https://instagram.com/vyraenterprises"),
                SettingEntity("business_email", "yvraenterprises.business@gmail.com"),
                SettingEntity("site_title", "VYRA ENTERPRISES"),
                SettingEntity("hero_heading", "THE TIMELESS EDIT"),
                SettingEntity("hero_statement", "Sartorial precision, refined silhouettes, and bespoke affiliate curation.")
            )
            dao.setSettings(initialSettings)

            // Seed Initial Luxury Products
            val initialProducts = listOf(
                // Men - Top
                ProductEntity(
                    title = "Double-Breasted Wool Overcoat",
                    description = "Impeccably tailored from virgin Italian wool with sharp peak lapels and horn buttons.",
                    brandName = "Maison Sartoriale",
                    gender = "Men",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-wool-overcoat",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Ribbed Pure Cashmere Knit Sweater",
                    description = "Spun from Mongolian grade-A cashmere in an understated oatmeal melange tone.",
                    brandName = "Atelier Nord",
                    gender = "Men",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-cashmere-sweater",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),
                ProductEntity(
                    title = "Sea Island Cotton Oxford Shirt",
                    description = "Hand-finished mother-of-pearl buttons and clean french placket in crisp ivory.",
                    brandName = "Couture Homme",
                    gender = "Men",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-oxford-shirt",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 3
                ),

                // Men - Bottom
                ProductEntity(
                    title = "Pleated Virgin Wool Flannel Trousers",
                    description = "Relaxed tapered silhouette with forward double pleats and side tab adjusters.",
                    brandName = "Maison Sartoriale",
                    gender = "Men",
                    category = "Bottom",
                    imageUrl = "https://images.unsplash.com/photo-1479064555552-3ef4979f8908?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-wool-trousers",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Tailored Belgian Linen Drawstring Pant",
                    description = "Breathable lightweight linen woven in Flanders with a gentle drape.",
                    brandName = "Atelier Nord",
                    gender = "Men",
                    category = "Bottom",
                    imageUrl = "https://images.unsplash.com/photo-1624378439575-d8705ad7ae80?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-linen-pants",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),

                // Men - Footwear
                ProductEntity(
                    title = "Goodyear-Welted Suede Chelsea Boots",
                    description = "Supple snuff suede treated for water resistance, set on a Dainite rubber sole.",
                    brandName = "Couture Homme",
                    gender = "Men",
                    category = "Footwear",
                    imageUrl = "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-chelsea-boots",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Minimalist Full-Grain Calfskin Sneaker",
                    description = "Low-profile design crafted with Italian Margom soles and buttery leather lining.",
                    brandName = "Atelier Nord",
                    gender = "Men",
                    category = "Footwear",
                    imageUrl = "https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-calfskin-sneaker",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),

                // Men - Accessories
                ProductEntity(
                    title = "Brushed Wool & Cashmere Fringe Scarf",
                    description = "Generously sized in warm camel with delicate self-fringed edges.",
                    brandName = "Vyra Heritage",
                    gender = "Men",
                    category = "Accessories",
                    imageUrl = "https://images.unsplash.com/photo-1520903920243-00d872a2d1c9?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-cashmere-scarf",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Vegetable-Tanned Leather Weekend Duffle",
                    description = "Hand-burnished bridle leather with solid brass hardware and detachable strap.",
                    brandName = "Vyra Heritage",
                    gender = "Men",
                    category = "Accessories",
                    imageUrl = "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/men-leather-duffle",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),

                // Women - Top
                ProductEntity(
                    title = "Tailored Double-Breasted Silk Blazer",
                    description = "Architectural shoulder silhouette crafted in heavy mulberry silk satin.",
                    brandName = "Maison Vyra",
                    gender = "Women",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-silk-blazer",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Asymmetric Draped Georgette Blouse",
                    description = "Fluid high neck blouse with cascading bias drape in champagne ivory.",
                    brandName = "Étoile Studio",
                    gender = "Women",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-draped-blouse",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),
                ProductEntity(
                    title = "Belted Wool Trench in Sand Stone",
                    description = "Substantial water-repellent gabardine with storm flap and tortoiseshell buckle.",
                    brandName = "Maison Vyra",
                    gender = "Women",
                    category = "Top",
                    imageUrl = "https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-wool-trench",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 3
                ),

                // Women - Bottom
                ProductEntity(
                    title = "High-Rise Wide-Leg Wool Crepe Pant",
                    description = "Elongating structured floor-length trousers with pressed crease and discreet pockets.",
                    brandName = "Étoile Studio",
                    gender = "Women",
                    category = "Bottom",
                    imageUrl = "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-wide-leg-pant",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Bias-Cut Silk Satin Midi Skirt",
                    description = "Effortless liquid drape that skims the silhouette in luminous warm beige.",
                    brandName = "Maison Vyra",
                    gender = "Women",
                    category = "Bottom",
                    imageUrl = "https://images.unsplash.com/photo-1583496661160-fb5886a0aaaa?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-silk-skirt",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),

                // Women - Footwear
                ProductEntity(
                    title = "Sculptural Kitten Heel Pointed Mules",
                    description = "Polished nappa leather with an architectural curved wooden heel.",
                    brandName = "Atelier Nord",
                    gender = "Women",
                    category = "Footwear",
                    imageUrl = "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-pointed-mules",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Knee-High Glove Leather Boots",
                    description = "Ultra-soft calfskin leather with subtle square toe and stacked leather heel.",
                    brandName = "Maison Vyra",
                    gender = "Women",
                    category = "Footwear",
                    imageUrl = "https://images.unsplash.com/photo-1535043934128-cf0b28d52f95?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-knee-boots",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                ),

                // Women - Accessories
                ProductEntity(
                    title = "Structured Leather Saddle Bag",
                    description = "Clean geometric profile in smooth saddle leather with brushed gold hardware.",
                    brandName = "Vyra Heritage",
                    gender = "Women",
                    category = "Accessories",
                    imageUrl = "https://images.unsplash.com/photo-1584917865442-de89df76afd3?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-saddle-bag",
                    isPublished = true,
                    isFeatured = true,
                    displayOrder = 1
                ),
                ProductEntity(
                    title = "Hand-Rolled Silk Twill Square Scarf",
                    description = "Monochrome geometric motif printed on 100% pure silk twill with rolled edges.",
                    brandName = "Vyra Heritage",
                    gender = "Women",
                    category = "Accessories",
                    imageUrl = "https://images.unsplash.com/photo-1601924994987-69e26d50dc26?w=800&auto=format&fit=crop&q=80",
                    bookNowUrl = "https://example.com/affiliate/women-silk-scarf",
                    isPublished = true,
                    isFeatured = false,
                    displayOrder = 2
                )
            )
            dao.insertProducts(initialProducts)

            // Seed Editorial Articles for Content
            val initialArticles = listOf(
                ArticleEntity(
                    title = "The Architecture of Modern Tailoring",
                    description = "Exploring how unconstructed blazers and balanced proportions define today's quiet luxury silhouette.",
                    content = """
                        Tailoring is undergoing a quiet renaissance. Moving away from rigid, constricting structures, modern sartorial design emphasizes fluid shoulder construction, natural drape, and pure fibers.

                        When selecting an investment piece, the weight of the wool and the craftsmanship of the lapel roll are crucial indicators of longevity. Pair relaxed double-breasted jackets with fluid trousers to establish an understated yet commanding presence.
                    """.trimIndent(),
                    coverImageUrl = "https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=800&auto=format&fit=crop&q=80",
                    isPublished = true
                ),
                ArticleEntity(
                    title = "The Monochromatic Capsule Wardrobe",
                    description = "A comprehensive editorial guide to curating harmonious tones across ivory, sand, and deep charcoal.",
                    content = """
                        A curated wardrobe relies not on excess, but on intentional tonal coordination. By anchoring your wardrobe in neutral shades—warm ivory, oat, and charcoal—each garment complements the next seamlessly.

                        Layer different textures: pair fine-gauge cashmere with structured worsted wool and smooth nappa leather to create tactile depth without relying on loud patterns.
                    """.trimIndent(),
                    coverImageUrl = "https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800&auto=format&fit=crop&q=80",
                    isPublished = true
                ),
                ArticleEntity(
                    title = "Footwear Craftsmanship: The Goodyear Welt",
                    description = "Why handcrafted welted boots and premium calfskin loafers remain the cornerstone of timeless style.",
                    content = """
                        The foundation of personal style begins with footwear. A Goodyear-welted shoe represents a pinnacle of artisan shoemaking: resilient, water-resistant, and entirely resolable for decades of wear.

                        Combined with full-grain calfskins that develop an organic patina over time, true luxury footwear only grows richer with every step taken.
                    """.trimIndent(),
                    coverImageUrl = "https://images.unsplash.com/photo-1608256246200-53e635b5b65f?w=800&auto=format&fit=crop&q=80",
                    isPublished = true
                )
            )
            dao.insertArticles(initialArticles)
        }
    }
}
