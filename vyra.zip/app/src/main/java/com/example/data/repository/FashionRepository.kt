package com.example.data.repository

import com.example.data.local.FashionDao
import com.example.data.model.ArticleEntity
import com.example.data.model.ProductEntity
import com.example.data.model.SettingEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class FashionRepository(private val dao: FashionDao) {

    // --- Products ---
    val allProducts: Flow<List<ProductEntity>> = dao.getAllProducts()
    val publishedProducts: Flow<List<ProductEntity>> = dao.getPublishedProducts()

    fun getProductsByGenderAndCategory(gender: String, category: String): Flow<List<ProductEntity>> {
        return dao.getProductsByGenderAndCategory(gender, category)
    }

    suspend fun getProductById(id: Long): ProductEntity? = dao.getProductById(id)

    suspend fun insertProduct(product: ProductEntity): Long = dao.insertProduct(product)

    suspend fun updateProduct(product: ProductEntity) = dao.updateProduct(product)

    suspend fun deleteProduct(product: ProductEntity) = dao.deleteProduct(product)

    suspend fun deleteProductById(id: Long) = dao.deleteProductById(id)

    // --- Articles ---
    val allArticles: Flow<List<ArticleEntity>> = dao.getAllArticles()
    val publishedArticles: Flow<List<ArticleEntity>> = dao.getPublishedArticles()

    suspend fun getArticleById(id: Long): ArticleEntity? = dao.getArticleById(id)

    suspend fun insertArticle(article: ArticleEntity): Long = dao.insertArticle(article)

    suspend fun updateArticle(article: ArticleEntity) = dao.updateArticle(article)

    suspend fun deleteArticle(article: ArticleEntity) = dao.deleteArticle(article)

    // --- Settings ---
    val allSettings: Flow<Map<String, String>> = dao.getAllSettings().map { list ->
        list.associate { it.key to it.value }
    }

    suspend fun getSetting(key: String): String? = dao.getSetting(key)

    suspend fun setSetting(key: String, value: String) {
        dao.setSetting(SettingEntity(key, value))
    }

    suspend fun ensureInitialData() {
        if (dao.getProductCount() == 0) {
            com.example.data.local.FashionDatabase.populateInitialData(dao)
        }
    }
}
